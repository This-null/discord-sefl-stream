const { Client, Message } = require("discord.js-selfbot-v13");

module.exports = {
  name: "join",

  /**
   * @param {Client} client
   * @param {Message} message
   * @param {string[]} args
   * @returns {Promise<void>}
   */
  execute: async (client, message, args) => {
    const channel =
      message.guild.channels.cache.get(args[0]) ||
      message.mentions.channels.first() ||
      message.member.voice.channel;
    if (!channel) return message.reply("Please provide a valid voice channel!");
    if (!channel.joinable)
      return message.reply("I cannot join that voice channel!");
    if (channel.type !== "GUILD_VOICE")
      return message.reply("That is not a voice channel!");

    const type = args[1]?.toLowerCase();
    if (!type) return message.reply("Please provide a valid type!");
    if (!["golive", "cam"].includes(type))
      return message.reply("Please provide a valid type!");

    await client.streamClient.joinVoiceChannel(channel, {
      selfDeaf: true,
      selfMute: false,
      selfVideo: type !== "golive",
    });
    if (type !== "cam") {
      await client.streamClient.connection.createStream(true);
    }

    if (channel.type == "GUILD_STAGE_VOICE") {
      try {
        await message.guild.members.me.voice.setSuppressed(false);
      } catch {
        try {
          await message.guild.members.me.voice.setRequestToSpeak(true);
          message.reply("Waiting for request to speak");
          await new Promise((resolve) => setTimeout(resolve, 5000));
          await message.guild.members.me.voice.setSuppressed(false);
        } catch {
          message.reply("Failed to request to speak");
          client.streamClient.leaveVoiceChannel();
        }
      }
    }
    return message.reply(`Joined ${channel}`);
  },
};
