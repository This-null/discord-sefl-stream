const { Client, Message } = require("discord.js-selfbot-v13");

module.exports = {
  name: "test",

  /**
   * @param {Client} client
   * @param {Message} message
   * @param {string[]} args
   * @returns {Promise<void>}
   */
  execute: async (client, message, args) => {
    const channel =
      message.guild.channels.cache.get(args[0]) ||
      message.mentions.channels.first() ||
      message.member.voice.channel;
    const voiceConnection = await client.streamClient.joinVoiceChannel(
      channel,
      {
        selfDeaf: false,
        selfMute: true,
        selfVideo: false,
      }
    );

    const streamConnection = await voiceConnection.createStream(true);
    const player = client.streamClient.createPlayer(
      "http://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4",
      streamConnection.udp
    );

    player.play();

    player.on("start", () => {
      console.log("Started playing");
    });

    player.on("finish", () => {
      console.log("Stopped playing");
    });

    return message.reply(`Joined ${channel}`);
  },
};
