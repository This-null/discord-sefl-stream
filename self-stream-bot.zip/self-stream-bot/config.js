module.exports = CONFIG = {
  configs: [{ token: "", voice: "" }],
  prefix: "!",
  owners: [""],
};
