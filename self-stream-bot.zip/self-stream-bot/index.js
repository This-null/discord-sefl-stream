const { Client } = require("discord.js-selfbot-v13");
const { DiscordStreamClient } = require("discord-stream-client");
const { readdirSync } = require("fs");

const { configs, owners, prefix } = require("./config.js");

for (const config of configs) {
  const client = new Client({ checkUpdate: false });
  const StreamClient = new DiscordStreamClient(client);

  StreamClient.setResolution("720p");
  StreamClient.setVideoCodec("H264");

  const commands = new Map();

  client.login(config.token);

  client.on("ready", () => {
    console.log(`${client.user.tag} is ready!`);

    readdirSync("./commands").forEach((file) => {
      try {
        const command = require(`./commands/${file}`);
        commands.set(command.name, command);
        console.log(`Loaded ${command.name} command!`);
      } catch (error) {
        console.log(error);
      }
    });
  });

  client.on("messageCreate", async (message) => {
    if (message.author.bot || !message.content.startsWith(prefix)) return;
    if (!owners.includes(message.author.id) && message.author.id !== client.id)
      return;

    const [commandName, ...args] = message.content
      .slice(prefix.length)
      .trim()
      .split(/ +/g);
    const command = commands.get(commandName);
    if (!command) return;

    try {
      await command.execute(client, message, args);
    } catch (error) {
      console.log(error);
    }
  });
}
